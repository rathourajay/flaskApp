import os
import sys
import json
import logging
import threading
import flask
import httplib
import requests
from flask import Flask, request, Response, jsonify

MEC_APPCATALOG_SERVICE_IP = "0.0.0.0"
MEC_APPCATALOG_SERVICE_PORT = '56000'

app_catalog_srvc = Flask(__name__)


class ApplicationCatalog:

    def __init__(self, file):
        self.lock = threading.Lock()
        self.file = file
        self.mtime = 0
        self.load_db()

    def load_db(self):
        mtime = os.stat(self.file).st_mtime
        if mtime != self.mtime:
            self.mtime = mtime
            with open(self.file) as app_file:
                logging.info(
                    "Loading application policy database %s" % self.file)
                self.db = json.load(app_file)
                logging.debug(json.dumps(self.db))

    def find_app(self, app):
        app_data = None
        self.lock.acquire()
        self.load_db()
        if app in self.db["applications"]:
            app_data = self.db["applications"][app]
        self.lock.release()
        return app_data


@app_catalog_srvc.route("/api/v1.0/centralrepo/appcatalog/<app_id>", methods=["GET"])
def details(app_id):
    return json.dumps(app_catalog.find_app(app_id))

logging.basicConfig(level=logging.INFO,
                    format='%(asctime)-15s %(levelname)-8s %(filename)-16s %(lineno)4d %(message)s')

app_catalog = ApplicationCatalog(
    "C:/Users/gur40998/workspace/discovery_server/centralrepo/appCatalog/app-catalog.db")

# Start the Flask web server (HTTP)
app_catalog_srvc.run(
    host=MEC_APPCATALOG_SERVICE_IP, port=MEC_APPCATALOG_SERVICE_PORT, threaded=True)
