import os
import sys
import json
import logging
import threading
import flask
import httplib
import requests
from flask import Flask, request, Response, jsonify

MEC_CLOUDLETCATALOG_SERVICE_IP = "0.0.0.0"
MEC_CLOUDLETCATALOG_SERVICE_PORT = '56001'

cloudlet_catalog_srvc = Flask(__name__)


class CloudletCatalog:

    def __init__(self, file):
        self.lock = threading.Lock()
        self.file = file
        self.mtime = 0
        self.load_db()

    def load_db(self):
        mtime = os.stat(self.file).st_mtime
        if mtime != self.mtime:
            self.mtime = mtime
            with open(self.file) as app_file:
                logging.info(
                    "Loading application policy database %s" % self.file)
                self.db = json.load(app_file)
                logging.debug(json.dumps(self.db))

    def load_cloudlets(self):
        self.lock.acquire()
        self.load_db()
        self.lock.release()

    def cloudlets(self):
        self.load_cloudlets()
        return self.db

    def update_status(self, cloudlet_id, status):
        self.db['cloudlets'][cloudlet_id]['status'] = status
        with open(self.file, 'w') as app_file:
            json.dump(self.db, app_file)


@cloudlet_catalog_srvc.route("/api/v1.0/centralrepo/cloudletcatalog/cloudlets", methods=["GET"])
def cloudlets():
    return json.dumps(cloudlet_catalog.cloudlets())


# @cloudlet_catalog_srvc.route("/api/v1.0/centralrepo/cloudletcatalog/<cloudlet_id>", methods=["GET"])
# def details(cloudlet_id):
#     if self.db["cloudlets"][cloudlet_id]:
#         return self.db["cloudlets"][cloudlet_id]
#     else:
#         return {}


@cloudlet_catalog_srvc.route("/api/v1.0/centralrepo/cloudletcatalog/<cloudlet_id>", methods=["PUT"])
def update(cloudlet_id):
    try:
        status = request.args.get('status')

        cloudlet_catalog.update_status(cloudlet_id, status)
        resp = Response(
            response="CLOUDLET UPDATION SUCCESS", status=httplib.OK)
    except:
        resp = Response(
            response="CLOUDLET UPDATION FAILED", status=httplib.INTERNAL_SERVER_ERROR)
    return resp


logging.basicConfig(level=logging.INFO,
                    format='%(asctime)-15s %(levelname)-8s %(filename)-16s %(lineno)4d %(message)s')

cloudlet_catalog = CloudletCatalog(
    "C:/Users/gur40998/workspace/discovery_server/centralrepo/cloudletcatalog/cloudlet-catalog.db")

# Start the Flask web server (HTTP)
cloudlet_catalog_srvc.run(
    host=MEC_CLOUDLETCATALOG_SERVICE_IP, port=MEC_CLOUDLETCATALOG_SERVICE_PORT, threaded=True)
